﻿# 在桌面创建带图标的快捷方式
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$desk = [Environment]::GetFolderPath('Desktop')
$shell = New-Object -ComObject WScript.Shell
$icon = Join-Path $root 'assets\广财抢场.ico'

$items = @(
    @{ Name = '广财抢场'; Target = '小程序.bat'; Desc = '体育馆场地预约小程序' }
)

foreach ($it in $items) {
    $lnkPath = Join-Path $desk ($it.Name + '.lnk')
    $target  = Join-Path $root $it.Target
    if (-not (Test-Path $target)) {
        Write-Host ("  [跳过] 找不到 " + $target)
        continue
    }
    $s = $shell.CreateShortcut($lnkPath)
    $s.TargetPath       = $target
    $s.WorkingDirectory = $root
    $s.IconLocation     = $icon + ',0'
    $s.Description      = $it.Desc
    $s.Save()
    Write-Host ("  已创建 " + $lnkPath)
}

Write-Host ""
Write-Host ("  来源目录: " + $root)
Write-Host "  提示: 这个文件夹以后不要移动或删除，快捷方式指向里面。"
